import React, { useCallback, useState, useEffect, useRef } from "react";
import { Box, Button, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import ScheduleModal from "./ScheduleModal";
import "./Calendar.css";
import axios from "axios";
import dayjs from "dayjs";
import CheckView from "./CheckVIew";
import Sales from "./Sales";
import { apiUrl, ISchedule, saveSchedule, closeModalUtil, openModalUtil, getSchedulesUtil } from "../utils/scheduleUtils";
import TUICalendar from "@toast-ui/react-calendar";
import "tui-calendar/dist/tui-calendar.css";

const Schedule = () => {
  const calendarRef = useRef<any>(null);
  const [schedules, setSchedules] = useState<ISchedule[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [currentYear, setCurrentYear] = useState<number>(dayjs().year());
  const [currentMonth, setCurrentMonth] = useState<number>(dayjs().month() + 1);
  const [currentSchedule, setCurrentSchedule] = useState<ISchedule | null>(null);
  const [newStart, setNewStart] = useState<Date | undefined>(undefined);
  const [newEnd, setNewEnd] = useState<Date | undefined>(undefined);
  const [startTime, setStartTime] = useState<string>("00:00");
  const [endTime, setEndTime] = useState<string>("00:00");
  const [newTitle, setNewTitle] = useState("");
  const [estPrice, setEstprice] = useState<number>(0);
  const [sort, setSort] = useState<string>("START");
  const [selectedCsKinds, setSelectedCsKinds] = useState<string[]>([]);
  const [userInt, setUserInt] = useState("");
  const [gubun, setGubun] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [rentPlace, setRentPlace] = useState<string>("1floor");
  const [customerEtc, setCustomerEtc] = useState<string>("");
  const [contactPerson, setContactPerson] = useState<string>("");
  const [contactTel, setContactTel] = useState<string>("");
  const [etc, setEtc] = useState("");
  const [csKind, setCsKind] = useState<number>(0);
  const [ADmedia, setADmedia] = useState<number>(7);
  const [id, setId] = useState<number>(0); // ID값
  const [moneyFinishNY, setmoneyFinishNY] = useState<number>(0); // ID값
  const [messageLogCount, setmessageLogCount] = useState<number>(0); // ID값
  const [vatSendCount, setvatSendCount] = useState<number>(0); // ID값
  const [isSmsModalOpen, setIsSmsModalOpen] = useState(false);
  const formatMonth = (month: number): string => {
    return month.toString().padStart(2, "0");
  };
  const start = new Date();

  const handleRefreshSchedules = useCallback(() => {
    getSchedulesUtil(currentYear, currentMonth, sort, setSchedules, formatMonth, selectedCsKinds);
  }, [currentYear, currentMonth, sort, selectedCsKinds]);

  useEffect(() => {
    // 초기 로딩 시와 상태 변경 시 스케줄 로드
    handleRefreshSchedules();
  }, [handleRefreshSchedules]);

  // 🚨 2. closeModal 유틸리티에 새로고침 함수를 전달하도록 업데이트
  const closeModal = useCallback(() => {
    closeModalUtil(setIsModalOpen, setCurrentSchedule, handleRefreshSchedules); // 새로고침 핸들러 전달
  }, [handleRefreshSchedules]); // 의존성에 추가

  const onSaveSchedule = async () => {
    if (!customerName.trim()) {
      alert("모든 필수 입력란을 작성해 주세요.");
      return;
    }
    let isSendingAlimtalk = false;
    if (modalMode === "create") {
      const shouldSendAlimtalk = window.confirm("알림톡을 발송하시겠습니까?");
      if (shouldSendAlimtalk) {
        isSendingAlimtalk = true;
      }
    }
    const closeAfterSave = isSendingAlimtalk ? () => {} : closeModal;
    await saveSchedule(
      csKind,
      ADmedia,
      newTitle,
      newStart,
      newEnd,
      startTime,
      endTime,
      customerName,
      rentPlace,
      modalMode,
      currentSchedule,
      gubun,
      userInt,
      estPrice,
      etc,
      setSchedules,
      closeAfterSave
    );
    if (isSendingAlimtalk) {
      // 이전에 추가한 setIsSmsModalOpen 상태 업데이트
      setIsSmsModalOpen(true);
    }
    getSchedulesUtil(currentYear, currentMonth, sort, setSchedules, formatMonth);
  };

  const openModal = useCallback((mode: "create" | "edit", scheduleData: ISchedule | null = null) => {
    openModalUtil(
      mode,
      scheduleData,
      setModalMode,
      setCurrentSchedule,
      setNewStart,
      setNewEnd,
      setStartTime,
      setEndTime,
      setNewTitle,
      setCustomerName,
      setRentPlace,
      setGubun,
      setUserInt,
      setEstprice,
      setId,
      setEtc,
      setIsModalOpen,
      setCsKind,
      setADmedia,
      setCustomerEtc,
      setContactPerson,
      setContactTel,
      setmoneyFinishNY
    );
  }, []);

  const fetchScheduleById = useCallback(
    async (id: string) => {
      try {
        const res = await axios.get(`${apiUrl}/api/schedules/${id}`);
        const scheduleData = res.data;
        setmessageLogCount(scheduleData.messageLogCount);
        setvatSendCount(scheduleData.vatSendCount);
        setmoneyFinishNY(scheduleData.moneyFinishNY);
        openModal("edit", scheduleData);
      } catch (err) {
        console.error("Error fetching schedule by ID:", err);
      }
    },
    [openModal]
  );

  const onClickSchedule = useCallback(
    (e: any) => {
      fetchScheduleById(e.schedule.id);
    },
    [fetchScheduleById]
  );

  const onBeforeCreateSchedule = useCallback(
    (scheduleData: any) => {
      console.log("onBeforeCreateSchedule");
      if (calendarRef.current) {
        const calendarInstance = calendarRef.current.getInstance();
        calendarInstance.createSchedules([scheduleData]);
      }
      openModal("create", scheduleData);
    },
    [openModal]
  );

  const onBeforeUpdateSchedule = useCallback(
    async (e: any) => {
      const { schedule, changes } = e;
      // 스케줄 업데이트 처리
      // console.log('onBeforeUpdateSchedule',schedule)
      calendarRef.current.calendarInst.updateSchedule(schedule.id, schedule.calendarId, changes);

      // 날짜와 변경된 값이 있을 때 처리
      const startDate = new Date(changes.start) ? new Date(dayjs(changes.start).format("YYYY-MM-DD")) : undefined;
      const endDate = new Date(changes.end) ? new Date(dayjs(changes.end).format("YYYY-MM-DD")) : undefined;

      // 새로운 스케줄 객체 생성
      const newSchedule: ISchedule = {
        id: schedule?.id || String(Math.random()),
        start: startDate ? startDate : undefined,
        end: endDate ? endDate : undefined,
        customerName: schedule?.customerName ? customerName : undefined,
      };

      try {
        await axios.put(`${apiUrl}/api/schedules/${schedule?.id}`, newSchedule);
      } catch (error) {
        console.error("Error updating schedule:", error);
      }

      // 상태 업데이트
      setNewStart(changes.start ? new Date(changes.start) : new Date(schedule.start));
      setNewEnd(changes.end ? new Date(changes.end) : new Date(schedule.end));
    },
    [calendarRef, currentSchedule]
  );

  const updateCurrentMonthYear = useCallback(() => {
    if (calendarRef.current) {
      const calendarInstance = calendarRef.current.getInstance();
      const date = calendarInstance.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      setCurrentMonth(month);
      setCurrentYear(year);
    }
  }, [calendarRef]); // calendarRef 의존성 추가

  const onDeleteSchedule = async (id: Number) => {
    console.log("onDeleteSchedule", id);
    const res = await axios.delete(`${apiUrl}/api/schedules/${id}`);
    getSchedulesUtil(currentYear, currentMonth, sort, setSchedules, formatMonth);
    closeModal(); // 모달 닫기
  };

  const onClickNextButton = () => {
    calendarRef.current.calendarInst.next();
    updateCurrentMonthYear();
  };
  const onClickPrevButton = () => {
    calendarRef.current.calendarInst.prev();
    updateCurrentMonthYear();
  };

  const reloadSchedule = async (selectedIds: string[]) => {
    setSelectedCsKinds(selectedIds);
  };
  const calendarOptions = {
    defaultView: "month", // 기본 뷰 설정 (month)
    month: {
      visibleScheduleCount: 8, // 하루에 보여줄 최대 스케줄 개수 설정
      moreLayerSize: {
        height: "auto", // "더보기" 레이어 높이 자동 조정
      },
    },
  };
  return (
    <div className="App">
      <Box
        sx={{
          margin: "0 auto",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: "5",
        }}
      >
        <Button onClick={onClickPrevButton} color="primary" variant="outlined">
          이전 달
        </Button>
        <Box sx={{ margin: "10px" }}>
          {currentYear}년 {currentMonth}월
        </Box>
        <Button onClick={onClickNextButton} color="primary" variant="outlined">
          다음 달
        </Button>
      </Box>
      <Sales currentYear={currentYear} currentMonth={currentMonth} />
      <CheckView
        reloadSchedule={reloadSchedule} // 이제 이 함수는 selectedCsKinds를 인자로 받습니다.
        currentYear={currentYear}
        currentMonth={currentMonth}
      />
      <FormControl fullWidth>
        {/* <InputLabel>기준</InputLabel> */}
        <Select value={sort} onChange={(e) => setSort(e.target.value)}>
          <MenuItem value="CREATECNT">생성일(건수)</MenuItem>
          <MenuItem value="CREATE">생성일</MenuItem>
          <MenuItem value="START">시작일</MenuItem>
          <MenuItem value="END">종료일</MenuItem>
          <MenuItem value="ADSPEND">광고집행</MenuItem>
        </Select>
      </FormControl>
      <TUICalendar
        ref={calendarRef}
        height="1000px"
        view="month"
        schedules={schedules}
        month={calendarOptions.month}
        onClickSchedule={onClickSchedule}
        onBeforeCreateSchedule={onBeforeCreateSchedule}
        // onBeforeDeleteSchedule={onBeforeDeleteSchedule}
        onBeforeUpdateSchedule={onBeforeUpdateSchedule}
      />
      <ScheduleModal
        isOpen={isModalOpen}
        modalMode={modalMode}
        id={Number(id)}
        csKind={Number(csKind)}
        ADmedia={Number(ADmedia)}
        newStart={newStart}
        newEnd={newEnd}
        startTime={startTime}
        endTime={endTime}
        newTitle={newTitle}
        gubun={gubun}
        userInt={userInt}
        estPrice={estPrice}
        customerName={customerName}
        etc={etc}
        customerEtc={customerEtc}
        contactPerson={contactPerson}
        contactTel={contactTel}
        rentPlace={rentPlace || ""}
        moneyFinishNY={moneyFinishNY}
        messageLogCount={messageLogCount}
        vatSendCount={vatSendCount}
        setNewStart={setNewStart}
        setNewEnd={setNewEnd}
        setStartTime={setStartTime}
        setEndTime={setEndTime}
        setCustomerName={setCustomerName}
        setRentPlace={setRentPlace}
        setNewTitle={setNewTitle}
        setGubun={setGubun}
        setUserInt={setUserInt}
        setEstprice={setEstprice}
        setEtc={setEtc}
        setCsKind={setCsKind}
        setADmedia={setADmedia}
        setCustomerEtc={setCustomerEtc}
        setContactPerson={setContactPerson}
        setContactTel={setContactTel}
        onDeleteSchedule={(id) => onDeleteSchedule(Number(id))}
        onSaveSchedule={onSaveSchedule}
        closeModal={closeModal}
        setmoneyFinishNY={setmoneyFinishNY}
        isSmsModalOpen={isSmsModalOpen}
        setIsSmsModalOpen={setIsSmsModalOpen}
      />
    </div>
  );
};

export default Schedule;
